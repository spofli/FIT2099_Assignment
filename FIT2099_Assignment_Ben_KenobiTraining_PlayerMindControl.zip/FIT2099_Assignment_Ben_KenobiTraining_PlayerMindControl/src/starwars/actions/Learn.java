package starwars.actions;

import edu.monash.fit2099.simulator.userInterface.MessageRenderer;
import starwars.SWActionInterface;
import starwars.SWActor;
import starwars.SWAffordance;
import starwars.SWEntityInterface;
import starwars.entities.actors.behaviors.AttackInformation;
import starwars.entities.actors.behaviors.AttackNeighbours;

public class Learn extends SWAffordance implements SWActionInterface {

	public Learn(SWEntityInterface theTarget, MessageRenderer m) {
		super(theTarget, m);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public int getPriority() {
		// TODO Auto-generated method stub
		return 1;
	}
	
	@Override
	public boolean isMoveCommand() {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean canDo(SWActor a) {
		AttackInformation attack;
		attack = AttackNeighbours.attackLocals(a,  a.getWorld(), true, true);
		return (a.getForcepoints() < 100 && attack == null);
	}

	@Override
	public void act(SWActor a) {
		SWEntityInterface target = this.getTarget();
		SWActor targetActor = (SWActor) target;
		a.say(a.getShortDescription() + " received training from " + targetActor.getShortDescription());
		a.setForce((a.getForcepoints()) + (int)(targetActor.getForcepoints()/5));
		if (a.getForcepoints() >= 100) { //higher than forcepoints cap
			targetActor.say(targetActor.getShortDescription() + " says: You are now one with the force, " + a.getShortDescription());
			a.setForce(100);
		}
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "receive training from " + target.getShortDescription();
	}
}

package starwars.actions;

import edu.monash.fit2099.simulator.userInterface.MessageRenderer;
import starwars.SWActionInterface;
import starwars.SWActor;
import starwars.SWAffordance;
import starwars.SWEntityInterface;

public class MindControl extends SWAffordance implements SWActionInterface {

	public MindControl(SWEntityInterface theTarget, MessageRenderer m) {
		super(theTarget, m);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int getDuration() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getPriority() {
		// TODO Auto-generated method stub
		return 1;
	}
	
	@Override
	public boolean canDo(SWActor a) {
		SWEntityInterface target = this.getTarget();
		SWActor targetActor = (SWActor) target;
		// TODO Auto-generated method stub
		return (a.getForcepoints() >= 20 && !targetActor.isMindControlled() && !targetActor.isDead());
	}

	@Override
	public void act(SWActor a) {
		SWEntityInterface target = this.getTarget();
		SWActor targetActor = (SWActor) target;
		a.say(a.getShortDescription() + " attempts to mind control " + target.getShortDescription());
		if (targetActor.getForcepoints()*2 >= a.getForcepoints()) {
			a.say("\t" + a.getShortDescription() + "'s force is too weak to mind control " + target.getShortDescription());
		}
		else {
			a.say(a.getShortDescription() + " uses mind control on " + target.getShortDescription());
			targetActor.setMindControl(true);
		}
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "attempt to mind control " + target.getShortDescription();
	}

}

package starwars.entities.actors.behaviors;

import starwars.SWActor;

public class TrainInformation {
	public SWActor actor;
	public TrainInformation(SWActor a) {
		actor = a;
	}
}

package starwars.entities.actors;

import edu.monash.fit2099.simulator.space.Direction;
import edu.monash.fit2099.simulator.userInterface.MessageRenderer;
import starwars.Capability;
import starwars.SWLocation;
import starwars.SWWorld;
import starwars.actions.Disassemble;
import starwars.actions.Move;
import starwars.actions.Oil;
import starwars.actions.Repair;
import starwars.actions.Take;
import starwars.entities.actors.behaviors.EntityInformation;
import starwars.entities.actors.behaviors.Follow;
import starwars.entities.actors.behaviors.Patrol;
import starwars.entities.actors.behaviors.RepairDroid;
import starwars.entities.actors.behaviors.AttackNeighbours;

public class R2D2 extends Droid {
	
	private Patrol path;
	
	public R2D2(MessageRenderer m, SWWorld world, Direction[] moves) {
		super(200, "R2-D2", m, world);
		// TODO Auto-generated constructor stub
		path = new Patrol(moves);
		capabilities.add(Capability.MECHANIC);
	}
	@Override
	public void act() {
		if (isDead()) {
			return;
		}
		say(describeLocation());
		// R2-D2s performs droidRepairing operations before everything else
		EntityInformation r2Action;
		r2Action = RepairDroid.repairAction(this, this.world);
		if (r2Action != null) {
			if (r2Action.affordance instanceof Repair){
				say(getShortDescription() + " is preparing to repair something");
			}
			else if (r2Action.affordance instanceof Disassemble){
				say(getShortDescription() + " is preparing to disassemble something");
			}
			else if (r2Action.affordance instanceof Oil){
				say(getShortDescription() + " is preparing to oil something");
			}
			else if (r2Action.affordance instanceof Take){
				say(getShortDescription() + " is preparing to take something");
			}
			scheduler.schedule(r2Action.affordance, this, 1);
			return;
		}
				
		// If R2-D2 has an owner, follow it
		if (owner != null) {
			// Attacking takes precedence over following the owner 
			EntityInformation attack = AttackNeighbours.attackLocals(this, this.world, true, true);
			if (attack != null) {
				say(getShortDescription() + " has attacked " + attack.entity.getShortDescription());
				scheduler.schedule(attack.affordance, this, 1);
				return;
		}
			// If nothing to attack:
			Direction direction = Follow.followOwner(owner, this, world);
			if (direction != null) {
				say(getShortDescription() + " follows " + owner.getShortDescription());
				Move myMove = new Move(direction, messageRenderer, world);
				scheduler.schedule(myMove, this, 1);
				return;
			}
		}
		// If R2D2 has no owner, default command is patrolling
		Direction newdirection = path.getNext();
		say(getShortDescription() + " moves " + newdirection);
		Move myMove = new Move(newdirection, messageRenderer, world);
		scheduler.schedule(myMove, this, 1);
		return;
		
	}
	@Override
	public String getLongDescription() {
		return this.getShortDescription();
	}

	private String describeLocation() {
		SWLocation location = this.world.getEntityManager().whereIs(this);
		return this.getShortDescription() + " [" + this.getHitpoints() + "] is at " + location.getShortDescription();
	}
}



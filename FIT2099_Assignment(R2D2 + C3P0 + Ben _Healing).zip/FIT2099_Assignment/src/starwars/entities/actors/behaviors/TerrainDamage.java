package starwars.entities.actors.behaviors;

import starwars.SWActor;
import starwars.SWLocation;
import starwars.SWWorld;
import starwars.entities.actors.Droid;


public class TerrainDamage{
	
	public void BadlandsDroid(SWActor actor, SWWorld world) {
		// Check if in Badlands
		// Take damage if so
		// Get Disabled if hitpoints drop to 0
		SWLocation location = world.getEntityManager().whereIs(actor);
		Droid droid = (Droid) actor;
		if (location.getSymbol() == 'b') {
			droid.takeDamage(5);
			droid.say(droid.getShortDescription() + " took damage from moving in Badlands!");
			if (droid.getHitpoints() <= 0) {
				droid.disable();
			}
		}
	}
}
			



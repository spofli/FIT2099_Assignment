package starwars.entities.actors.behaviors;

import java.util.ArrayList;
import java.util.List;

import edu.monash.fit2099.simulator.matter.Affordance;
import edu.monash.fit2099.simulator.matter.EntityManager;
import starwars.SWActor;
import starwars.SWEntityInterface;
import starwars.SWLocation;
import starwars.SWWorld;
import starwars.actions.Disassemble;
import starwars.actions.Oil;
import starwars.actions.Repair;
import starwars.actions.Take;
import starwars.entities.DroidParts;
import starwars.entities.actors.Droid;

public class RepairDroid {

	public static EntityInformation repairAction(SWActor actor, SWWorld world) {
		SWLocation location = world.getEntityManager().whereIs(actor);
		EntityManager<SWEntityInterface, SWLocation> em = world.getEntityManager();
		List<SWEntityInterface> entities = em.contents(location);
		
		// look for a repairDroidAction
		// This in priority order is:
		// (1) Repair droid if holding parts
		// (2) Oil droid
		// (3) Disassemble droid
		// (4) Pick up droidparts
		ArrayList<EntityInformation> repairActions = new ArrayList<EntityInformation>();
		
		// Repairing
		if (actor.getItemCarried() instanceof DroidParts) {
			for (SWEntityInterface e: entities) {
				if ( e!= actor && (e instanceof Droid)) {
					for (Affordance a : e.getAffordances()) {
						if (a instanceof Repair) {
							repairActions.add(new EntityInformation(e, a));
						}
					}
				}
			}
		}
		// Get random repair target if exists
		if (repairActions.size() > 0) {
				return getRepairAction(repairActions);
			}
		// Oiling
		for (SWEntityInterface e: entities) {
			if (e instanceof Droid) {
				if (e.getHitpoints() < ((SWActor) e).getMaxHitpoints()) {
					for (Affordance a : e.getAffordances()) {
						if (a instanceof Oil) {
							repairActions.add(new EntityInformation(e, a));
						}
					}
				}
			}
		}
		// Get random oil target if exists
		if (repairActions.size() > 0) {
			return getRepairAction(repairActions);
		}
		// Disassembling
		for (SWEntityInterface e: entities) {
			if (e instanceof Droid) {		
				for (Affordance a : e.getAffordances()) {
					if (a instanceof Disassemble) {
						repairActions.add(new EntityInformation(e, a));
					}
				}
						
			}
		}
		// Get random disassemble target if exists
		if (repairActions.size() > 0) {
			return getRepairAction(repairActions);
		}
		
		// Picking up Parts
		for (SWEntityInterface e: entities) {
			if (e instanceof DroidParts) {		
				for (Affordance a : e.getAffordances()) {
					if (a instanceof Take) {
						repairActions.add(new EntityInformation(e, a));
					}
				}
						
			}
		}
		// Get random part to pick up if exists
		if (repairActions.size() > 0) {
			return getRepairAction(repairActions);
		}
		return null;
			
	}
	// Method to choose one possible target at random
	public static EntityInformation getRepairAction(ArrayList<EntityInformation> actionsList) {
			return actionsList.get((int) (Math.floor(Math.random() * actionsList.size())));
		}
	}
		

			


	
	


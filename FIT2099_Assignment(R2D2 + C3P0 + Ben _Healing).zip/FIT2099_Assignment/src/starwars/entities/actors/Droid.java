package starwars.entities.actors;

import edu.monash.fit2099.simulator.matter.Affordance;

import edu.monash.fit2099.simulator.userInterface.MessageRenderer;
import starwars.SWActor;
import starwars.SWAffordance;
import starwars.SWWorld;
import starwars.Team;
import starwars.actions.Oil;
import starwars.actions.Own;
import starwars.actions.Repair;
import starwars.actions.Attack;
import starwars.actions.Disassemble;

public abstract class Droid extends SWActor {

	private String name;
	protected SWActor owner;
	private Boolean isDisabled;
	/**
	 * Create a Droid.  
	 * 
	 * Droids will follow their owners if they have one
	 * (Move until they are on the same square)
	 * Droids will also attack any enemies not on the owners team.
	 * 
	 * If the Droid has no owner, it will perform it's default behavior each turn.
	 * 
	 * Droids can be oiled.
	 * Droids become disabled when their hitpoints drop to 0 and below
	 * A Disabled droid can be repaired/disassembled
	 * 
	 * Unlike other actors, Droids can change teams - follow their owners
	 * Droids begin with a NEUTRAL team. (Will not attacked by other entities)
	 * 
	 * @param hitpoints
	 *            the number of hit points of this Droid. If this
	 *            decreases to below zero, the Droid becomes disabled
	 * @param name
	 *            this Droid's's name. Used in displaying descriptions.
	 * @param m
	 *            <code>MessageRenderer</code> to display messages.
	 * @param world
	 *            the <code>SWWorld</code> world to which this
	 *            <code>Droid</code> belongs to
	 * 
	 */
	public Droid(int hitpoints, String name, MessageRenderer m, SWWorld world) {
		super(Team.NEUTRAL, hitpoints, m, world);
		// TODO Auto-generated constructor stub
		this.name = name;
		
		//Begin with no owner
		this.owner = null;
		
		//Set disabled to False at start
		this.isDisabled = false;
		
		//Droids can be oiled!
		SWAffordance Oil = new Oil(this,m);
		this.addAffordance(Oil);
		
		//Droids can be taken ownership of
		SWAffordance Own = new Own(this, m);
		this.addAffordance(Own);
		
		
	}
	// Method to disable the droid..
	// Adds Repair and Disassemble Affordances
	// Removes Oil Affordance, Attack Affordance(Important if droid STARTS out disabled)
	public void disable() {
		isDisabled = true;
		for (Affordance a: this.getAffordances()) {
			if (a instanceof Oil || a instanceof Attack) {
				this.removeAffordance(a);
			}
		}
		SWAffordance repair = new Repair(this, this.messageRenderer);
		this.addAffordance(repair);
		SWAffordance disassemble = new Disassemble(this, this.messageRenderer);
		this.addAffordance(disassemble);
	}
	
	// Method to enable the droid..;
	// (Called after repairing!)
	// Adds Oil Affordance
	// Adds Attack Affordance
	// Removes Repair & Disassemble Affordance
	public void enable() {
		isDisabled = false;
		for (Affordance a: this.getAffordances()) {
			if (a instanceof Repair || a instanceof Disassemble)  {
				this.removeAffordance(a);
			}
		}
		SWAffordance oil = new Oil(this, this.messageRenderer);
		this.addAffordance(oil);
		SWAffordance attack = new Attack(this, this.messageRenderer);
		this.addAffordance(attack);
	}
	public void changeOwner(SWActor actor) {
	//Changes the droid's owner
		owner = actor;
	}
	public Object getOwner() {
		return owner;
	}
	// Check if disabled
	public Boolean getIsDisabled() {
		return isDisabled;
	}
	@Override
	// Special only to droids, if disabled, will show in its description
	public String getShortDescription() {
		if (getIsDisabled()) {
			return name + " the droid[disabled]";
		} else {
			return name + " the droid";
		}
	}


}


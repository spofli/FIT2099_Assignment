package starwars.entities.actors.behaviors;

import java.util.List;

import edu.monash.fit2099.simulator.matter.EntityManager;
import starwars.SWActor;
import starwars.SWEntityInterface;
import starwars.SWLocation;
import starwars.SWWorld;

public class TrainTarget {
	public static TrainInformation trainLuke(SWActor actor, SWWorld world, boolean avoidNonFriendlies, boolean avoidNonActors) {
		SWLocation location = world.getEntityManager().whereIs(actor);
		EntityManager<SWEntityInterface, SWLocation> em = world.getEntityManager();
		List<SWEntityInterface> entities = em.contents(location);

		// select the trainable things that are here
		TrainInformation a = null;
		for (SWEntityInterface e : entities) {
			// Figure out if we should be training this entity
			if( e != actor && 
					(e instanceof SWActor && 
							(avoidNonFriendlies==false || ((SWActor)e).getTeam() == actor.getTeam()) 
					|| (avoidNonActors == false && !(e instanceof SWActor)))) {
				if (e.getShortDescription() == "Luke") {
					a = new TrainInformation((SWActor) e);
					return a;
					}
			}
		}
		return a;
	}
}

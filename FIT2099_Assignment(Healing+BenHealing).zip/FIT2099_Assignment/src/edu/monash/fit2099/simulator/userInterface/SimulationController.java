package edu.monash.fit2099.simulator.userInterface;

/**
 * SimulationController: placeholder for control portion of UI
 * 
 * @author 	ram
 * @date 	17 February 2013
 */

public interface SimulationController {

}

package starwars.entities.actors.behaviors;

import java.util.ArrayList;
import java.util.List;

import edu.monash.fit2099.simulator.matter.Affordance;
import edu.monash.fit2099.simulator.matter.EntityManager;
import starwars.SWActor;
import starwars.SWEntityInterface;
import starwars.SWLocation;
import starwars.SWWorld;
import starwars.actions.Take;
import starwars.entities.Canteen;

public class takeCanteens {

	public static EntityInformation findCanteens(SWActor actor, SWWorld world) {
		SWLocation location = world.getEntityManager().whereIs(actor);
		EntityManager<SWEntityInterface, SWLocation> em = world.getEntityManager();
		List<SWEntityInterface> entities = em.contents(location);
		
		// find canteens that exist!
		ArrayList<EntityInformation> canteens = new ArrayList<EntityInformation>();
		for (SWEntityInterface e: entities) {
			// Check if there are any non-empty canteens around
			if ( e!= actor && (e instanceof Canteen)) {
				for (Affordance a : e.getAffordances()) {
					if (a instanceof Take){
						if (!((Canteen) e).isEmpty()) {
							canteens.add(new EntityInformation(e, a));
							break;
						}
					}
				}
			}
		}
		// If there's a non-empty canteen, pick one up
		if (canteens.size() > 0) {
			return canteens.get((int) (Math.floor(Math.random() * canteens.size())));
		} else {
			return null;
		}
	}
}
	
			


	
	


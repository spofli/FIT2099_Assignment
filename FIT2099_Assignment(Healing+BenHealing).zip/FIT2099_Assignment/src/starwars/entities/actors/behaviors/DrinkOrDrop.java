package starwars.entities.actors.behaviors;


import edu.monash.fit2099.simulator.matter.Affordance;
import starwars.actions.Drink;
import starwars.actions.Leave;
import starwars.SWActor;
import starwars.SWEntityInterface;

public class DrinkOrDrop {
	
	public static EntityInformation findDrinkable(SWActor actor) {

		//Get item carried and drink affordance
		//Gets leave affordance if emptied
		SWEntityInterface itemCarried = actor.getItemCarried();
		for (Affordance aff: itemCarried.getAffordances()) {
			if  (aff instanceof Drink) {
				Affordance leaveAffordance = aff;
				return new EntityInformation(itemCarried, leaveAffordance);
			}
		}	
		for (Affordance aff: itemCarried.getAffordances()) {
			if  (aff instanceof Leave) {
				Affordance leaveAffordance = aff;
				return new EntityInformation(itemCarried, leaveAffordance);
			}
		}	
		return null;
	}
}
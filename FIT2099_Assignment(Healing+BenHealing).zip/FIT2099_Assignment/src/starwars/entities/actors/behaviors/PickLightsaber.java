package starwars.entities.actors.behaviors;

import java.util.List;

import edu.monash.fit2099.simulator.matter.Affordance;
import edu.monash.fit2099.simulator.matter.EntityManager;
import starwars.SWActor;
import starwars.SWEntityInterface;
import starwars.SWLocation;
import starwars.SWWorld;
import starwars.actions.Take;
import starwars.entities.LightSaber;

public class PickLightsaber {

	public static EntityInformation findLightsaber(SWActor actor, SWWorld world) {
		SWLocation location = world.getEntityManager().whereIs(actor);
		EntityManager<SWEntityInterface, SWLocation> em = world.getEntityManager();
		List<SWEntityInterface> entities = em.contents(location);
		

		// find lightsaber
		for (SWEntityInterface e: entities) {
			// Check if there are any lightsabers
			if ( e!= actor && (e instanceof LightSaber)) {
				for (Affordance a : e.getAffordances()) {
					if (a instanceof Take) {	
							return new EntityInformation(e, a);
					}
				}
			}
		}
		return new EntityInformation(null, null);
		}
	}
	
	
	
			


	
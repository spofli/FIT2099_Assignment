package starwars.entities.actors.behaviors;


import edu.monash.fit2099.simulator.matter.Affordance;
import starwars.actions.Leave;
import starwars.SWActor;
import starwars.SWEntityInterface;

public class DropItem {
	
	public static EntityInformation findCarriedItem(SWActor actor) {

		//Get item carried and leave affordance
		SWEntityInterface itemCarried = actor.getItemCarried();
		for (Affordance aff: itemCarried.getAffordances()) {
			if  (aff instanceof Leave) {
				Affordance leaveAffordance = aff;
				return new EntityInformation(itemCarried, leaveAffordance);
			}
		}	
		return null;
	}
}